# Selected publication evidence — 14 October 2026

Start with evidence/docs/PUBLICATION_EVIDENCE_PACKAGE_2026-10-14.md and
manifest.json. SHA256SUMS alongside the archive verifies the archive bytes.
The manifest identifies all selected files. Raw reports preserve historical
statuses; closeout_reconciliation_01 supersedes the original AOR timing/CPU
interpretation. Historical PASS.json can still state pending later stages.

AOR-S1 software qualification is complete. Padé build completion is recorded;
34.80 MHz is a tool estimate, not qualified timing. Latest Surd CPU candidate
placement is PASS; routing/timing is blocked by incomplete timing coverage.
No AOR hardware, silicon, speedup or energy claim is supported.

Source snapshots retain dirty-checkout identity. Surd RTL files are present-day
reference snapshots, not asserted to match every historical experiment. The
frozen AOR source manifest was rechecked when copying. Historical artifact
manifests retain their recorded paths; they are not all portable dependency
recipes. Referenced files not selected remain repository/local evidence links.

Excluded: large placed/routed netlists, chip databases, external tool binaries,
most historical experiments, bitstreams and full dependencies. This is not a
complete FPGA rebuild bundle. No new campaigns or public posting were run.
